define(function (require) {
  alert('You have included the test plugin!');
});